---
layout: page
title: About Mixyll
permalink: /about/
tags: about
---

This Jekyll theme was originally crafted by [John Otander](http://johnotander.com) as [Pixyll](https://github.com/johno/pixyll) and modified by [Sai Kiran Sripada](https://www.saikiransripada.com/).

Checkout the [Github repository](https://github.com/saikiransripada/mixyll) to download it,
request a feature, report a bug, or contribute. It's free, and open source
([MIT](http://opensource.org/licenses/MIT)).

Thanks to the following:

* [Pixyll](https://github.com/johno/pixyll)
* [BASSCSS](http://basscss.com)
* [Jekyll](http://jekyllrb.com)
* [Refills](http://refills.bourbon.io/)
* [Type Scale](http://type-scale.com/)
