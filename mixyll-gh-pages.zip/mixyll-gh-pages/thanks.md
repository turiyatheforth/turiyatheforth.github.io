---
layout: page
title: Thanks For Your Message
permalink: /thanks/
---
{{ site.text.thanks }}